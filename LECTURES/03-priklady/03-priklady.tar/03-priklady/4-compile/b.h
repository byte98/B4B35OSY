
extern int i_b;

int f_b(long int x);