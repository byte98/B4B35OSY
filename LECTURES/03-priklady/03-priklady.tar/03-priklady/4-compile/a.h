extern int i_a;

int f_a(short int x);